# TejaswiniSangana_CleanCode
  SimpleAndCompoundInterest class is used to calculate both Simple and Compound Interest

  HouseConstruction class is used to calculate the cost of house construction
